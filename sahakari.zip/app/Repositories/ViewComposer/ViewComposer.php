<?php
namespace App\Repositories\ViewComposer;
// use App\Repositories\Dashboard\DashboardRepository;
use App\Repositories\Setting\SettingRepository;
use App\Repositories\Scheme\SchemeRepository;
use Illuminate\View\View;

class ViewComposer {
	// private $dashboard;
	private $setting;
	
	public function __construct( SettingRepository $setting, SchemeRepository $scheme) {
		// $this->dashboard=$dashboard;
		$this->setting=$setting;
		$this->scheme=$scheme;

		

	}
	public function compose(View $view) {
		// $dashboard=$this->dashboard->first();
		$setting=$this->setting->first();
		$scheme=$this->scheme->orderBy('created_at', 'desc')->where('publish',1)->get();
		// dd($scheme);


		$view->with([ 'setting_composer'=>$setting,'view_scheme'=>$scheme]);

	}
	
}
